#!/bin/bash

cd /var/stratum/config/ && ./run.sh $*

