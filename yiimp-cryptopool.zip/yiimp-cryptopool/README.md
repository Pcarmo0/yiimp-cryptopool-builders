### Welcome to the cryptopool.builders github!
### This fork of YiiMP is designed to work with our Ultimate Crypto-Server Installer program.
Trying to install this on a server not built by our installer will cause headaches, frustrations, and screaming loudly at your monitor.

#### Please go to https://github.com/cryptopool-builders/Multi-Pool-Installer for our installer.

## Changes to this fork include but not limited to:

```
- File structure -
$STORAGE_ROOT/yiimp/site/web
$STORAGE_ROOT/yiimp/site/stratum (Only on single server installs)
$STORAGE_ROOT/yiimp/site/configuration
$STORAGE_ROOT/yiimp/site/crons
$STORAGE_ROOT/yiimp/site/log
$STORAGE_ROOT/yiimp/starts

- Site Files-
Updated various files to work with new file structure
```


## Donations for continued support of this script are welcomed at:
* BTC 3DvcaPT3Kio8Hgyw4ZA9y1feNnKZjH7Y21
* BCH qrf2fhk2pfka5k649826z4683tuqehaq2sc65nfz3e
* ETH 0x6A047e5410f433FDBF32D7fb118B6246E3b7C136
* LTC MLS5pfgb7QMqBm3pmBvuJ7eRCRgwLV25Nz

## Credits:

* Thanks to tpruvot for the yiimp release
* Thanks to mailinabox for the installer idea
